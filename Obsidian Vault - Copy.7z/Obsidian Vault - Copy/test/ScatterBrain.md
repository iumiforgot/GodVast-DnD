Entering the market there's immediately a surplus of optiions, myraids of dimly lit booths that continue as far as you can see. Almost every stall being hawked by a merchant. Nearly everything that you can imagine is being sold here. 
While window shopping, you see many things that are familiar, interspersed with items that are totally alien to you.
Just out of character really quickly : This is completely open ended, you can go find a booth for anything you can think of, which of course, as you learn more about this area, whether it be by discovering things out in the wild, or finding random curiosities at these booths. Ontop of this, these merchants look wealthy, they'd certainly buy some of your goods for resale. 
And, for the sake of brevity, once you purchase your basics, we'll determine what's a "gotta have it" type of item, which'll automatically restock, for a price, before you leave town.
[examples : clothing, rations, good food, navigational tools, maps, locations of dungeons, weaponry and it's ammo, some more arcane inclined spots]
Artifacts stall : Contains many somewhat rare artifacts, all retailing for similar prices, modulated by a couple dozen percent based on their reasonable demand. This is about all this stall contains.

Pillar collapse : The magnetic [and magic!] influence of the lodestone vanished as the pillar collapses, tones of rock crash into thousands of degrees, stripping it of every physical and arcane aspect of the glassy rock, as the total mass discharges an immense magical storm, as above, so below. This destruction, especially due to its discharge, will fuck with navigation, permanently.
Slightly unbeknownst to the party, the destruction is marked by a monopole, a strongly repulsing magnet, that destroys every compass, and will alert most people across the vast, or at least in the section of the vast.

Exhaustion leading to memory death in an enemy, mid combat, and the breakdown it entails.

The sky is black as night, a tectonic rumbling can
be heard overhead; the ruins sprawl out with a
fractal madness, and a vast sea of colorless sand
stretches out into the darkness