The sky is black as night, a tectonic rumbling can
be heard overhead; the ruins sprawl out with a
fractal madness, and a vast sea of colorless sand
stretches out into the darkness