Are a major faction within the vast, with significant force within every city, but usually beholden to their largest employer, the Contrivance Company.
Candlekeepers are pretty particular, holding all of their members to a high standard. Most Candlekeepers tend towards lawful good, and there is an immediate way to determine how "in" they are. If someone has taken the oaths, they will have a varying amount of candles stuck to their armor and clothing, usually situated behind their heads, as they keep these candles burning constantly. Every Candlekeeper has an aura of light of 20 feet because of this, but they do not suffer from the usual bright-eyed effect of this. If a Candlekeeper walks into the radius of another light source, they will still have the regular bright-eyed effects.

**The oath** [Which is usually witnessed by a senior keeper] : 
In our twilight world,
Paragons make certainty.
The toil; mine alone.

**The benefits** 
When anyone within sight of a Candlekeeper would otherwise gain a level of exhaustion OR lose a memory, the Candlekeeper can choose to take the level of exhaustion, instead. 