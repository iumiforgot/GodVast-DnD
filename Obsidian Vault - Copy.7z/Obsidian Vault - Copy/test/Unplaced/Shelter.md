Based off of two factors, where you end up sleeping at night, and what modifiers you possess.

[//environment]
In bags : The worst kind of sleep, does nothing on its own.

Impoverished : Freely available in towns, but a roof over your head provides a base of good base, removing 1 [[exhaustion]] every long rest.

Paid : costs about 2 pennies a person, provides [[Food & Water]] & lodging , entertainment, removes 5 [[exhaustion]] every long rest, a very fulfilling stay.

[//modifiers ]
Campfire kit : purchasable in town, wax pods that slowly burn & radiate heat, may "scare" away monsters, gives a bonus of -1 [[exhaustion]] per long rest. Ie: Bags now reduce 1 exhaustion, Impoverished can instead reduce 2.

Other improvements may get expensive to be enjoyed crew-wide.