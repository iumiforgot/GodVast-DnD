**The baseline**
0 exhaustion, and in a vacuum, exhaustion does not change per day. This is modulated by [[Food & Water]], alongside nightly [[Shelter]]

**The rule**
Every level of exhaustion is a random STAT bearing an injury, every roll made with this stat is made at disadvantage.

There is no grand change in this formula before exhaustion level 5

Level 5 Movement speed halved.
Level 6 HP [MAX] halved. Does not reduce current HP, only max.
Level 7 Loss of a memory, Temporarily reduce to Level 0 Exhaustion.