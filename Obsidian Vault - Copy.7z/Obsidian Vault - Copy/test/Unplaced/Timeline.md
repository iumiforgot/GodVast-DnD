For babyboom (spurned by Legion & Warforged)
At least 20 years (7300 days) have passed from the legion making significant progress & giving people hope for a better tomorrow, causing a baby boom.
The baby boom that'd be caused by an actual feeling of hope, not so much of finality, but of purpose.
The boomers have all factionalized, now that the Vast has sufficient population to do such a thing, into the Traders, Candlekeepers, and the bigbads.
Harnessing a celestial to power them, wildly unpopular topside, causing a quick collapse to this empire. This celestial was supposed to follow, after warforged had made enough progress, but due to time dilation, they did not make it in time, communication ceased, and the legion just continued, following last orders.

7300 days, at 1 day -> 1 year, would be 7300 years since robots were created to explore the vast. Perhaps the only robots made, ever. 

@2 days -> year, 3650 years, 
@4, 1825, a particularly long dark age. It would take the crew 400 days to travel 100 years, still significant, but @18miles a day, 7200 miles to complete, it's much more punchy @ 2 days, even more so at 1, but that is a HUGE dark age. That's outside interference. Oh gods, the pillars?

