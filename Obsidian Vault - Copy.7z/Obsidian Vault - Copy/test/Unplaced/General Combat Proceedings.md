Base AC
Aeneas 13
Anais 13
Bramble 17
Elaric 13
Lysandra 13
Sylvia 15

Moonbeam : Stays up for a minute, can move once per turn (action), requires CON save of 14, 
2d10 radiant damage or half.

Flaming Sphere : Stays up for a minute, can move (action), requires DEX save of 12, 
2d6 flame damage or half
#fight 
[[pt Fight]]