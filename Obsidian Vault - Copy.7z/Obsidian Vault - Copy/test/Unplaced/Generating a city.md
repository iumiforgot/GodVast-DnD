Purpose is based off of proximity usually.
Towns near pillars will be largely lode manufacturers, with waning domestic supports.
Towns inbetween towns serve as rest stops, have very high candlekeeper & CC populations.
1d6 : New purpose
1. Depots (Of bells, wax, rations, bricks, )
2. Strategic location (Forward position, resupplying depo)
3. Fresh Food (crit 1d6 = Water)
4. Redundancy
5. 
6. The town has lost its lifeblood of [roll again], and is dying.
Settlement Generation (Bookwise)
**d4 Mood**
1 Peaceful but Sullen
2 Quiet but Anxious
3 Active but Desperate
4 Mirthful but Pained
**1d6 Who They Are**
1 Merchants and brokers
2 Storytellers and singers
3 Warriors and cutthroats
4 Artisans and craftsmen
5 Prophets and philosophers
6 Explorers and cartographers
**1d8 They Have...**
1 A working smithy
2 Collections of maps
3 A reservoir of water
4 Hunting grounds of insects
5 Stores of lodestone
6 A well-known bazaar
7 Armory of tools and weapons
8 A dangerous artifact
**1d10 Prominent Locals**
1 Magus, with books for sale
2 Dervish, with a coat of blades
3 Masque, whispers secrets
4 Boot seller, none are pairs
5 Pyromancer, jars fire for use
6 Scrollmeister, deals in spells
7 Black Helm, dangerous rogue
8 Wastecrier, delivers news
9 Nod, smiles and never speaks
10 Flutist, songs return memories
**1d12 Problem**
1 Food will soon run out.
2 Water has been vanishing.
3 Locals are disappearing.
4 Metal is scarce.
5 Tools are rusting away.
6 A political schism.
7 The complex is collapsing.
8 A great death has occurred.
9 Someone is a murderer.
10 An artifact in the ruins stirs.
11 Dangerous beliefs arise.
12 Crawl have moved in.