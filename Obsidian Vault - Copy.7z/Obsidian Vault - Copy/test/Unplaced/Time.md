The day is broken up into 6, 4 hour chunks. Forgive the solar-centric phrasing, but there is 

Sunrise, 
Noon, 
A BONUS, 
Sunset, 
[Dusk,]
[Midnight]

Within 4 hours the party can travel 10km, which is a wonderful pace. 

While travelling, the party can choose to use their bonus action to travel another 10km (Maximum of 40km [4 hexes] while still sleeping) at the cost of 1 [[Exhaustion]] for everyone in this travelling group.

Lysandra and Aeneas both only sleep for 4 hours, so can have either dusk or midnight as a free slot to do something.