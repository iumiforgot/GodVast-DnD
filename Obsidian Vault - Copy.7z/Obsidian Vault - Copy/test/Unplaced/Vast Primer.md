The Vast, above all else, is a mystery
No one understands why you end up here, and only a handful of people have ever been able to harness the phenomenon.
The Vast is humongous, nobody within it has ever discovered an end, although it's rare that someone would even search for it.
It exists alongside the world, in an isolated sense. Most people remember coming from their homes, at least for a time, and while these people vary & may lack knowledge of each others nations, it is the general consensus that they've all come from the same realm.
One of the most devious parts of this place is its inherent corruption. Chiefly, everyone cracks, and The Vast will ingress into a weak mind, making reaching a breaking point a certainty. After a certain point, people have come to declare the soul gone, the person within having "gone home".
The Vast doesn't just corrupt the mind, it corrupts the entire body. People experience unique changes, bodies adapt and heal.. But corpses.. They fester, and within days they return, twisted and warped, nigh unrecognizable. No humanity survives this process. They do not eat, drink, or sleep. It's as if the land itself gives them power. It's quite clear that they still hunger; the stories that come back from the wastes are.. horrific. 
The only consistent way to prevent this is cremation. 

Due to recent factions bringing The Vast together, stories have spread of distant relatives meeting one another, or of the even rarer meeting of a fable character. All of these circumstances, with such disparaging timeframes, The Vast is a timeless place.
The Vast itself, is a gray desert encompassing a mind-boggling area. Interspersed throughout this are gargantuan columns of a stygian black rock called Lodestone. In areas of importance long forgotten, are buildings..
-Columns : Their size at the base is 6 miles, and they reach up, with no visible end. They are extremely useful for common people, since they are made of currency, and serve as navigational aids. Everyone who needs to leave town knows their pillars by heart, and how to orient themselves off of them. There's whispers about pillars collapsing. There is something about these structures that attracts the natural monsters of The Vast in troves. 
-Buildings : Concrete complexes, standing tall & covering a lot of land. Modest buildings here dwarf the citadels - say the ex-citizenry. Suited for habitation, either human or inhuman. Most cities will nestle in these, shanty towns housing the lost.

Lodestone itself is a helpful mineral. It is a rock that seethes with mana. Its arcane connection is not understood, but much like gold above, it is used for magic anyways. Proper usage of lodestone remains esoteric to most of the Lost. Due to its burden, though undeniable value, it's represented through coinage.
Throughout The Vast are stores of supplies, such as fuels, textiles, tools; and more rarely, artifacts.
The weather is temperate, with almost nonexistent weather phenomena. There have been times of extreme activity, which have been becoming more frequent. Townsfolk have vanished under sandstorms before.. only to worm their way up changed.

Modern day : There's been an unprecedented factionalization of The Vast in the past 20 years, people have been aligning themselves with 3 major powers throughout The Vast. 

The Contrivance Company , Originally a city-wide guild of crafters, quickly coming to dominate the supply of its main ingredient: lodestone. Once supplies were sured up, their expansion was uncontested & they became the most powerful force in The Vast. While their positive effect is undeniable, the company has been tightening its grip in recent years.

The Candlekeepers, a band of fighters largely serving as a protective force for cities, caravans, and excursionary forces. Almost every fighter worth their salt will be fighting under their oaths. Upholding your classic chivalric values & fighting for a better, safer vast. They chomped at the bit to replace The Lost Chapters.

And the now mostly deprecated Lost Chapters. A 200 strong warforged army. While these robots will proudly report their original numbers, and their programmed purpose; they conflate these with their current objectives. After 20 years in The Vast, more than a hundred losses, and no "Legion" to be seen, seemingly nobody but them believes in their objectives. They have gone from a purifying force of The Vast, to a lethargic and forgotten faction.

The Twins : One of the largest towns within The Vast, not all inhabited, of course, but a very large sprawl of buildings inbetween two pillars. It has been continuously inhabited for an estimated 100 years. Feeling quite the resurgence, as did all other towns, with the help of the Lost Chapters & booming population real safety brought. It has not been long since calamity gripped the city, the portside pillar imploded just 2 moons back. Most of the portside buildings have been demolished, and the pillar narrowly missed the starboard pillar on its way down. Rubble seals the cities stern, making a quite dangerous pass but an almost safe barricade.
[[World Primer]]