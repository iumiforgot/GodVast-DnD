Up - Forwards
Down - Backwards
Top Left - Slight Left
Top Right - Slight Right
Bottom Left - Back Left
Bottom Right - Back Right

Progressing alongside [[Time]]

Within 4 hours the party can travel 10km, which is a wonderful pace. 

While travelling, the party can choose to use their bonus time to travel another 10km (Maximum of 40km while still sleeping) at the cost of 1 [[Exhaustion]] for everyone in this travelling group.

Orientation either through unique bearing-gyros, or through aligning off of the environment. IE, pillars, building orientation.

Pedometers, to measure crit success / fail rolls adding / removing distance for the day.

#item 