In CC territory, especially in the CC HQ, players will be brought to a man who cannot forget a face upon infractions & the like, judging them & granting vouchers & the like.
Older fellow with almost no memories left, basically shell of a man whose left to remember every single person who he's ever seen. [the vision passed on through illusions & the like, he is not the only one, but he is made useful despite age & degradation]
[This person could be very important, in solving the mystery]
[Would almost certainly remember the statue man, not in his golden state, and would take a very certain depiction of him in order to even chance it, since he has changed so much between now and then. He would not have even been gold, when they met.]
[But It would be a name, and a place to look.]