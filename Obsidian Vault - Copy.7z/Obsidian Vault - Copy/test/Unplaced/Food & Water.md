Rations provide 1 day of food, and 1 day of water.
Dry Rations provide 1 day of food, and no water.
Town

**Starvation :** 
Prevents you from regaining any points of [[exhaustion]] by sleeping, even in good conditions [even in town]. Survival while starving will take great caution to avoid gaining any points of exhaustion.


**Dehydration :** 
Sleeping while dying of thirst gives you 1 level of [[exhaustion]], rather than removing 1 level, even in good conditions. This is not offset by things like a campfire.

**Exhaustion :** 
Happens when the party pushes themselves too far. The party gains 1 level of exhaustion.
Usually, this is done during the BONUS TIME [[Time]] of day,
Also occurs when the party does not sleep at the proper times. (Sleeping 4 hours, good for 8.)