Consult everyone about their character sheets, especially Linas, its uh. Hamstrung.

Maps : Foggy sandy area for [[2.3 An Altercation]], Snaking urban sprawl for entering town, and the market surrounding the lighthouse.

Rework or make clear the first gate puzzle. Needs to have an air of "we're not supposed to be here", that encourages them to delve deeper, and to corner themselves. It could work with ashes enlarge / shrink, at least a little bit.

Maybe rebalance skill proficiencies from 2 (only 20%, to be a bit stronger?)
[later: I think i'm OK with this being a 20% improvement for these more passive skills, especially including how strong the base stats are already.. maybe if i remove some points from them, then sure.]

deprecated : 

Armor & Hit Mechanics :
Example would be an AC 10 plate armor. A full coat of plates, heavy armor. 
Base "CC" is determined by challenging incoming melee attacks (automatic contests)
IE, 5 attack versus 5 attack, equal chances of hitting versus missing.
If the attack exceeds the defense, the attack has landed.
If the difference exceeds the enemies AC, it will do full damage, 
however, if it does not exceed the AC the attack will instead do 1 will, 1 body.

[[Guards]]