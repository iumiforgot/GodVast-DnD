Perception check, person in front.
Freebie : Hmm.. the hair is all wrong, his mustache and his hair are totally different.
Moderate : High cheeks, that defined nose. Close, but impossible to say thats "him"
Difficult : That's him. Total match on the side profile.. he's a lot older than when this was minted.

---
After The Fact / Light Source
---
A side profile of a well groomed, not-quite-so middle aged man, big mustache, jutting, yet thin nose, and defined forehead. The mans head hair is actually a bit of a let down, thinning, and recessed. The coin, and skillful illustration on it, captures a lot of this mans qualities. His stern features, and complimenting thick twirled mustache make him quite the statesman. You feel like he inspires a lot of confidence here.

#item 