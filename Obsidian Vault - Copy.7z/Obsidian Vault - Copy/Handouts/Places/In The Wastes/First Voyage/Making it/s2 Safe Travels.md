Navigating by keeping the pillar to your right, and bearing forwards, your day is dictated by keeping the lodestone rubble close to your vision. 
Unlike the pillar in town, this rock doesn't burn through the dark. You can only see its outlines out about 120 feet, just like anything else. So as you're walking, it's always within view, and every so often you hear noises coming from the rubblefield. The ground you walk on is interspersed with black rocks. [They don't look like lodestone, they look.. warped, cracked, split.. like spent lode]

But your travels continue, uninterrupted. The noises never seem to move with you, only ever emanating from certain points as you pass, coming and going as you pass particularly rowdy areas.

10, 20, 30 km pass under your feet, and you, as expected, see nothing.

[Afternote, travels went fine, no issues since time was running a little short, & the town or runaway will give enough hassle.]

[[Tent Town]]