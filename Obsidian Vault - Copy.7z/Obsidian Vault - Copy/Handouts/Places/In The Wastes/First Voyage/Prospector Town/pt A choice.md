The party is stuck between multiple rocks, they walked into the tent, hoping to belay suspicion and find an opening in which they could attempt to find Leviticus, but in, what can only be assumed as a characteristic blunder from the ginger second-in-command, the party has found themselves in possession of Leviticus, and with a noose tightening. The whole camp is assumedly rallying, after the loud chewing out that the barkeep gave Sturges, the oaf that got you all into this situation.

The tent is made of a pretty crappy material, definitely not a wall nor a barrier. From Lysandra's scouting, the lodestone rubble is only like 100 meters from the tents. The only issue this would present is adding to total travel time, and having to travel through the lodestone; with the horrors that presents.

[[pt Scamper]]

If they choose to stay, the tent's just gonna get ripped to shreds, attacks flying through the panels of the tent & attacking blindly at first, but then basically vanishing as cover

[[pt Fight]]