He [oz] whips his hand around, and the ginger[sturges] lad returns. 
"Get these folk situated in a tent" He clears his throat abruptly,
"In a tent"

"Right this way.. uhm. folk" He doesn't walk you very far, the camp stretches for far longer than you can see, other lights dot & illuminate sides of the rubble, not very densely, mind you, but they spread as far out as a mile. You quickly come up to a tent, the bolt of fabric serving as the door is loose & blocking the view inside, except for the weft of it. Light shines brightly through in pinpricks, and dully lights up a grid, about an inch across. [Weak fabric. Crappy stuff]
The man stands backwards to the tent, to the right side of the door, crosses his hands infront of himself, hands resting on the haft of his slung axe and says 
"No weapons, though"
"Dead serious", hostile body language.
[Wait for a response, moment they touch a weapon]
"I'm just fuckin with yaaaaaa.. where do you think we are."
A furtive pat on the back of first person to touch their weapon.
He walks away laughing to himself, pointing to himself, and pointing at your crowd with his thumb, counting up a whole hand. he is wholly content.. funniest shit ever.. 

The tent is all yours.

[Leviticus is inside, laying down, Ophelia is watching the door, wide eyed. Whoever opens the door sees Ophelia staring at them first. She'll wake her father, and they'll both kind of watch in horror. The back is a valid way out]

[Might have to stop here, we'll see]

[Leviticus & Ophelia are unarmed, camp took their weapons. Basically prisoners]
"STUUUUUUURGES. WHY ARE YOU BACK ALREADY. NO. NO DON'T FUCKING KID WITH ME. I'M DONE."
[Couple seconds, basically a grace period to think of a way out]
A shrill whistle blares, rapidly fluttering [a very clear, premeditated signal], and you hear boots walk by the tent.

[[pt A choice]]
#people 