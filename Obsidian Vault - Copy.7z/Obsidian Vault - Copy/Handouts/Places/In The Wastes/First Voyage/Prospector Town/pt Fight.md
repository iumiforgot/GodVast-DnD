Oz : /roll 2d6ro<2+2
Great sword proficiency fighter, maybe a throwing axe.
Sturges : /roll 1d12+4
Great axe, not that great but strong swings.

The group will attempt to surround or meet in a fight, I think it will be kind of close, if not, there could be chance to call for reinforcements if the bartender has not gone down.

The barkeep will cry "kidnappers!" attempting to goad the Candlekeepers into the fight. They're lawful good, stealing a CC bounty is chaotic as best, it's against their deal but not enough to just straight into it.

[[General Combat Proceedings]]
#fight
