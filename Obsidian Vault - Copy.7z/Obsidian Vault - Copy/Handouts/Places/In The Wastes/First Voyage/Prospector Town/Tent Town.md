It's a small little gathering, the shadows of fabric-angles dance as the light of the central brazier dances. There are small slabs laid on the ground, making kneeling tables. The sand serves as "good enough" seating, it seems. Tools from workers lay next to glasses of water, and other.. more colorful.. beverages.

As you approach the central meeting area, you see what looks to be a bartender, taking care of the thirst of a few men & women that are at his tables. As you walk up, a shorter ginger man kicks the bartender, causing a conditioned response.
The man bows down, bringing his ear to level with the ginger-mans mouth, and he listens whilst talking to his tables, smiles, corks and rolls a bottle over to the folks way at the end. The ginger man walks off, quickly blurring into the dark

[[pt Bartender]] #places 