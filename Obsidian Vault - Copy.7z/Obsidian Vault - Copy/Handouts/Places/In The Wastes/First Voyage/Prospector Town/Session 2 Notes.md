Leviticus and Ophelia are bound, after the colossal fuckup from Sturges, the ginger goon. 
Ophelia is gagged, two very CON heavy people are wielding her & her father, in off hands. 

Sturges just got screamed at, the gig is kind of up, but there's time in between now & the tent being surrounded. The gang just found out why Oz was calling Sturges stupid. That was a considerably large mistake. Like, dozens of guilds worth of ransom. Oz is pissed, understandably.

This has taken a minute at most, the crew'll have about half that before there's people nearby, and another half until they're surrounded.

Elaric and Oz are decently familiar, not on names, but the expedition leader certainly knows him, blonde capable ranger all of the sudden coming in with a group of people asking for names & causing trouble.