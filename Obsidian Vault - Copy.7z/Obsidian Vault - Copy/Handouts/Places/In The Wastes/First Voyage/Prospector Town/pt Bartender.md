[Oz]
Gruff man, paying more attention to paying customers and more permanent members of the town than the party. Just a gutteral kind of man, not a fan of middlemen, and knows trouble when he sees it.

Interrupt the third question, "One sec", he quickly shuffles away, his words hardly registering before he's moved to another table, moving bottles around, laughing, and slightly pushing a loose tool towards a patron, before coming back. "You were saying",

[When Leviticus is mentioned, he'll light a candle on his table]
[Within a few minutes Ginger'll be back & kick him once more, whisper into his ear, before Oz turns & whispers into Gingers ear.]
"We 'aven't seen 'em"
[They have seen him. He's still in town, but you just confirmed their suspicions, that's THEIR bounty to take.]
"Who the hell brings a child here e'en?"
"If he was planning on makin' it roight, he'd go straight to CC, avoid that whole frontier justice bidness."
He scratches at the back of his neck, kind of exasperated at the amount of questions. It's clear to you this man is a creature of habit, and press conferences are not his natural habitat. "Look." A deep sigh. "If you're not here to work.. and you don't want nothin' to drink.. I'm not sure what I can do for you.. You want a room? I'm just bout done with talking to bounty hunters, you guys are bad news. Always."

[[pt a room (Oaf)]]

#dialogue #people 