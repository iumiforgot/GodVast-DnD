10,20,30 km. Unneccesary. The party will almost always travel 30km, mostly without seeing ANYTHING. Mostly, just days passing. They should be semi aware of just how much time they are spending in here.
**It's usually going to be a:**
Walk, show the changes [Talk?], Sleep,[Talk?] Wakeup.. 
**Alongside:** 
Removal of exhaustion if garnered. (I.E. Inside, running a campfire.)
Consumption of rations. (Every 2 days if dry rations.)

Irregularities concerning a pedometer.
Every so often, you lose or gain distance. Should skew towards loss. IE crit 1 d10 loses 10 km, crit 10 d10 is 50 50 between gaining or losing ground. 75% lose, 25% win? might be a bit too much.