In the center of Twins, there lies a large building, compounding architecture [This one has a mix of insets, and buttresses that form a brutalist style of columns. this continues in wild but repeatable patterns] It is too tall to see the roof, and the walls stretch into the horizon. Following the footpaths, you quickly come to an entrance. a vaulted section quickly reaches to hold up the walls, and two massive doors are not quite fully open. [These doors are nearly 3 foot thick of concrete.]
Just past the doors lays a reception area, carved into the floor of this massive, and otherwise empty entryway, are tables, benches, and a few people [3] diligently writing onto rags, copying under candlelight.
Up in front is an elf, sitting splayed behind his desk [on a stone chair, with two pillows under his legs] He is watching his hand write and reading another piece of paper by the light from a candle that dimly flickers on his desktop. He has not noticed your arrival yet, and neither have the other two people who are only visible from the dancing of their own candles.
Coming closer, you step down a few steps into this in-situ office. Pebbles crunch under your feet, and you have gained the attention of the elf at the desk. [Peregrine]

"Welcome."
[This is the office of the council of twins, culpable for the management of the cities food, water, exports and imports. We're the governmental body of twins, without government we're just blind in the dark. One person can only do so much, no?]
"Do you have an appointment?"
"I see. I'm afraid we've ceased taking walk ins.. since.. [He scratches at his throat, all semblances of professionalism briefly leaving his face, and he seems to let the silence speak for him.] "Every councilman needs as much time to convene with critically important matters. As much time as possible." [He's right back into his spiel]
"I've got their schedules here, if you'd like to schedule an appointment I'd just need your vouchers."

"Your vouchers.. from CC? [Contrivance Company.]" 
At the slight downturn of the conversation, he pulls his paperwork in a little, now sitting up straight.
"There's not much I can do to help you if you cannot even prove your identity."
"You will have to take that up with the company, I am no liaison"
#dialogue #twins 