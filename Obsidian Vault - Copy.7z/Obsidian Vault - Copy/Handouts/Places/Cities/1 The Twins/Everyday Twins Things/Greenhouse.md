[Growing hardy plants, tended to by a druid & pupils]
[Druid is struggling to understand the two druids in the party wanting to keep up the life of adventurers.. this is not like the old world. seeing their skills, he can offer them a lot, but it is ultimately a job, that would remove them from the game. it is at most a fallback to the characters. the job would be enough to support 1 person & some fun, or just barely two people.]
#dialogue #twins
