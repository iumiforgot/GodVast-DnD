When re-entering twins, through Elarics safer route, it is important to keep someone with good sight upfront, to search for oncoming patrols.
Whoevers in front, roll a 1d6.
1. Guards vv
2. A distant horn blows, follow by 2 more response horns getting closer on that same [left/right] side, and finally by a response horn on the [opposite] side, seems like a guard is coming. [Stealth, tuck away, hide, if spotted, then guardsvv]
3+ You pass without issue.
A single guard, patrolling the wall detects you, and begins to run away the moment you lock eyes, the moment he blurs into the murky gray horizon you hear him blow a muster call on his horn, and you hear the replies of [2d4] guards responding via horn. No guards are currently at your position, you have a couple of options. [Run in, out, wait]
#people #twins 