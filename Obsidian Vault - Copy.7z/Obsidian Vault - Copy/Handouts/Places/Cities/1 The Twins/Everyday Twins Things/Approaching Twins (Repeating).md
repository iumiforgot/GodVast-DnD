Whoever's taking point, roll a dice, d6.
1 = [[Guards]]
2 = You hear the distant blare of a horn on your left side, followed by further, and more horns on your left. Flip a coin. Tails is a horn on your right. Otherwise, it's just 3 with flavor. If another horn on the other side, then you gotta hide or you may be seen, not going to be expected though, so you will see them FIRST & have time to hide.
3+= Nothing happens, you approach the segments of the wall without trouble, and are quickly immersed between the monotone walls of these buildings. They looked uninhabited, filthy, and aged. This sprawl continues for at least a mile, the tower, now only visible in passing, reveals that much.
#twins 