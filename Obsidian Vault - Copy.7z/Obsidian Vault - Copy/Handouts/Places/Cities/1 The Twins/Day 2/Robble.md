[Defacto Tour Guide]

Entering the tent, there is a feeling of isolation, the tent is large, but struggles to house all of you, pieces of slate rest against the walls, shelfing overflows with these rocks everywhere, with bright white lines carved into them. Throughout the room hang pieces of fabric with similar markings, except these are drawn in black ink. 
There is a tall [7'2"], cloaked person, standing defensively, watching over the sitting merchant: a sinewy looking elf. He's sat on a stuffed chair with legs crossed, eyes wide open but not seeing. A furrowed brow and [The elf is lost in thought, he has not given any indication of knowing you're even in the tent] An introduction might be an order.

Once the conversation dies down, Atlas either gives Aeneas or the party the map of town, depending on circumstance. If party asks for a map of town, he'll tell them to go copy it from Aeneas, because he doesn't remember it & he's not gonna do it again.

#dialogue 