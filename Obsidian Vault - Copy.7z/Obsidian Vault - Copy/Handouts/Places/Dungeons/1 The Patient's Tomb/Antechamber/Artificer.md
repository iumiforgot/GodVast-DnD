Artificer : An imposing looking man, with a sharp angular face, and beat brow. He looks like an archetypical wizard, but his clothes are tight fitting and look utilitarian. You cannot see the bottom, due to the statue being inset, or cut off by the stone.
[Arcane]
-Freebie : There isn't anything magical in, on, or within the statue.
-Moderate : Some semblance of magic thrums beneath the statue. It is difficult to detect
-Difficult : Life-giving magic pulses throughout the stone, combined with the telltales of mechanical interference, the unseen machine is pushing and pulling this magic out of the stone constantly, beating laboriously and diligently.

[[p9 Awakened Artificer]]