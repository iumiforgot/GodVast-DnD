Tables : Only two tables still stand, single chairs are dispersed nearby tables, alongside wooden splinters sticking up through the dust. 
Investigation
-Freebie : All of these wooden objects have been destroyed, crushed down flat on the ground. all of the nails have fallen out and rusted.
-Moderate : The wood is bone dry, its bands long split across as it swelled and rotted. Rusty strips of metal dot the tabletops, and conjoining nails. Very little remains of what these used to be, or what these tables were for.
-Difficult ^ : Rotted and rusted metal tools lay uselessly welded in the tabletop of an old workbench. These have been here for an extremely long time, and though there is little left, you cannot recognize the shape of any of these tools, despite their simple designs. 