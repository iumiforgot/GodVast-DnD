A massive antechamber, deliberately cut from the stone that has so tightly hugged the walls of this dungeon, suddenly bulges out, the floor taking on a cone shape, at least 50 feet across. In the middle, a medium sized golden statue lay on the other end of the room. Two doors flank the statue on each side. The floor is covered in a still dust that sticks to your feet and flies to the air as you step inside. [This dust is so oppressively dense, that if you were prone, you would take suffocation damage at the beginning of your turn.] Scattered throughout the room are tables, chairs, and piles of wood scrap. 
[[Statue]]

[[Artificer]]

[[p3 Doors]]

[[Tables]]
