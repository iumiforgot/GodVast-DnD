It's a pentagonal stone slab, with a carved man on the surface of the stone. He juts out of the stone halfway. This would have been difficult to carve. 
[Perception Check]
-Freebie : It's quite well done, the man is captured in exquisite detail. The beard alone is immaculate.
-Moderate ^: The stone making up the man looks completely different from that of the slab, and the walls, for that matter. He's not carved at all, looks smooth like he was cast. 
-Difficult ^^ : & while you can see no more with your eyes, running your fingers across the cold, inert stone, you can feel the slightest gap between the concrete-cast man, and the pentagonal slab. These are two seperate pieces.

[[Artificer]]