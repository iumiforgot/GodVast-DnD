Doors : Two circular stone doors, inset into the wall, possess no handles or any sort of leverage.
-[Difficult to open, but not impossible with enough effort. They slowly roll into, and most notably, up the wall. They open towards the slab left door opens right vice versa, and will give extreme resistance if attempted to roll the wrong way. Will immediately roll shut if nothing is holding / propping it open.] As you peer into the room, you see a dimly lit hallway.

[[p4 Twisting Halls]]