The golden statue is laying flat across a flat, bland pentagonal stone slab. The statue is slightly inset into the slab, palms down. It looks to capture the likeness of a man, but the craftsmanship looks very poor.

What he looks like : [[Artificer]]

Attempt to move : [[Annoying The Artificer]]

[Perception Check]
Freebie : The statue is covered, from head to toe, in fin-like deficiencies. These glaring mistakes draw your eye in closer, realizing that the entire statue is asymmetrical, lumpy, and of terrible quality. If it were not made from gold, you couldn't imagine even giving this away to someone. 
^Moderate: 
Without weighing this, it would be impossible to estimate if it was a fully golden statue, or just gold plated. You reckon, from the weight of your own pockets, that this statue would still weigh somewhere near 1000 pounds, 450 Kilos, if it were gold plated.
^Difficult With Attempt To Move : 
This statue weighs an immense amount. It is almost certainly solid gold.
[Religion]
Freebie : Many statues, in towns you've been to at least, attempt to capture the likeness of a god of some kind, whether imbued into a mortal, or in their true forms.
^Insane Critical Roll : This statue, however deformed, still captures the key features of the "True God". Dating its construction to within

[[Artificer]]