
BLAM! You hear and feel an extremely loud metallic *thud* shake the earth beneath you. 
[The gate has closed, the Artificer is on the hunt. Due to the party being unlikely to flee, either frightened could be used in the hallways (kinda pushy and not quite there), or  he could wait for them in the antechamber, they will eventually realize there is nothing here for them.]

[[p9 Awakened Artificer]]