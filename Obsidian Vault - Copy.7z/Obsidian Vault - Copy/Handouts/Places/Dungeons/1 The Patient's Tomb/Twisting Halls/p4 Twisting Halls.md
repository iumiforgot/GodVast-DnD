Twisting Halls : As you finally surpass the [left/right] stone door, you come to a dimly lit hallway, less than 5 feet wide, forcing you into a single file line. On both sides of the wall, volcanic glass bulges out in repeating offset pods. The roof, floor, and connecting walls look starkly different than the antechamber you have just passed through. [The stone of the hallways is a terrible pocked bubbly mess, it looks as though it was burnt in oil.]Though only dimly lit, there is certainly a space behind the glass. The floor of the hallway is grated, and has bundles of pearlescent purple wires running down the hall.
Perception.
-Freebie : There's a humanoid outline in the back of the pod.
-Moderate ^: Its shape seems to always be looking at you, while you peer through different sections of the impure glass.
-Difficult ^^ : Staring for quite a long time you realize how that is possible. These are indents of human forms, Set halfway into the wall. You can see no more through this difficult glass.

[[Breaking the Glass]]

[[p5 Following the Wires]]
