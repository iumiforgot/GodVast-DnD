	Purple Fluid : Numerous vials present themselves on the hull of the machine, one is toroidal, one is tombstone-shaped, one is an hour glass, one contains a piston that creates a plasma as the machine cycles. Perception :
-Freebie : The Toroidal vial pulses every second, the pearlescent fluid flowing beautifully on its inside. The pistoned ampule defies your understanding. The tombstone, or perhaps window shaped glass is completely empty. The hourglass shaped vial, is emptying quite quickly as it has nearly run out.
[Investigation]
-Difficult ^ : That curved shape is remarkably similar to.. the gate. that you had to open.. to get inside. Following the top of the hourglass leads back to the gate vial.

*[When this vial empties, nothing immediately happens, but the artificer has awoken and will begin closing off exits, if any remain open, and then hunting down the party]

[[p8 Closing Off Exits]]