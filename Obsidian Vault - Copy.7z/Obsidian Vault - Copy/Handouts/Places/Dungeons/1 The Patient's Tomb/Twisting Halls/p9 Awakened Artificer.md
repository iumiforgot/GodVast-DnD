Artificer Descriptor : The statue looks you in the eyes. His entire body is gilded, his movements slowed, but not stopped by recalcitrant joints.
The floor beneath him cracks, this much weight, moving on its own accord, is worrying.
[Attacks on sight]
[No emotion visible]
[Looks mercurial, almost]


[[p10 Artificer Combatant]]