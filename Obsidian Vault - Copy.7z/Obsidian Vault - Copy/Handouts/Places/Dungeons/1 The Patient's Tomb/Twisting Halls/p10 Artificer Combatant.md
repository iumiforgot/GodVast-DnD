Artficer Combatant: He is massive, a walking arcane outlet. Stiff & struggling with surges of magical force. very slow moving with wires following behind him. 
-He will not use melee, 17dv spell caster, can cast twice per turn, the dust deals 1d6+2 when someone starts their turn inside of it
-Molten Bloom, Make molten and manipulate a gallon of rock. Dex save, deals 3d6 damage, or half. There is a fixture of glass from the source of rock to the point of attack.
-Stone Ribs Strength Save (forces you prone and restrained requiring 1/2 of movement to attempt to break free, prone & restrained : attacks in advantage, attacks out disadvantage, cannot move or be moved without breaking the ribs, disadvantage on dex save)
-> On down, if someone has stone ribs, when they would roll a death save, they instead skip their turn.
-Flight(60 ft bonus action, kicks up a shit ton of dust, 1/6th (20 feet wide) cone in the path of movement, ) He scrapes the ground as he moves impossibly fast without propulsion.
-Boulder Dex Save Deals 3d6 or half (kicks up a 20 foot line starting anywhere + a plus at impact, making a long cross of dust, blocking visibilty and suffocating whoever starts their turn in it.)  
-*-Legendary Action Pall. All of the dust in the room kicks up, it shimmers with metal and glass grit, however beautiful, it is all you can see, and you dread drawing breath. You can see 5 feet max. You will begin to suffocate for 1d6+2 everytime you start your turn within the dust. This will last 5 turns.
-Melee attacks against him roll, but always hit, their damage is reduced by his AC (20). 
-The party can attempt to hit the wires, challenging his acrobatics if he can see the attack. This will cause a very slow DoT that will not save the party in time, even if all wires are cut. 

[THEY WILL DIE, THEN]

The basalt ribs constrict your chest tightly, forbidding you from drawing breath, and slowly pushing the last of your air out of your lungs. The murky gray dust swirls in the air, its turbulent flow coming slowly to a stop as the fight settles. Discomfort closes your eyes automatically, and the pain of grit under your eyelids keeps them closed. Even as your body is disturbed from its resting place, you cannot bare to look at what you know to be the statue. While his golden boots pound the ground, you can almost hear something between the booms of bass.
[Challenges to learn more]
[Hearing] Grants a foreign language that he's speaking, distinctive, but not quite helpful. He's not so much talking to you, but to himself. No one knows this language. It would be hard to even describe. 
[Sight] Grants very little
[Smell] There's a slight odor of sulfurous metal
[Touch] You feel the statues body thrum with life inbetween the thunderous sound of his footsteps.

Being manuevered upright, the pain leaves your body, vanishing in a wave up your spine.

[[Memories]]