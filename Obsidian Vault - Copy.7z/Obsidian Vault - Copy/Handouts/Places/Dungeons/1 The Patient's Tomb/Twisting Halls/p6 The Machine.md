The Machine : It still shines, but has specs of rust accumulating on its hull. Investigation.
-Freebie : Peeling up the loose hull of the machine, its underside is spotless, this machine looks brand new, whatever it is.
-Moderate ^: Interlocking gears whirr and rebound, once a second. Pink amethyst bearings roll between oversized brass parts. This machine has been made to last.
-Difficult ^^ : In fact everything has been made redundant, from what you can see, there are at least 3 ways to do the same thing on this machine. For *everything* that this machine does. There are simple tensioners working those valuable bearings until they are the size of sand.

Levers : You cannot discern what any one does, they are laid out in a 4x5 grid, with no markings at all. 
[just make it seem like fun, the machine makes noise, grinds, and eventually, one lever I'll ask, "are you sure", and this lever will make a bulb blow, making everyone in the room flip a coin to see if they go blind for 30 seconds]

[[Malfunction]]

Apertures : They look like heavy duty shelves, securely sealed via an overengineered collage of brass apertures.


[[p7 Purple Fluid]]
