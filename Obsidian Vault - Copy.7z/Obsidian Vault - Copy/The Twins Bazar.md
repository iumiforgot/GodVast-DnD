Continue : You can only catch glimpses of this bastion, as you begin to enter the bazar. Dozens of people buzz around, as you appear to be in the densest section of tents and stands. 

Bazar : Will be the area where players go to restock supplies that theyve designated on their sheets, rations (water), general supplies. they can dig into it if they want, but not upon first arriving.

