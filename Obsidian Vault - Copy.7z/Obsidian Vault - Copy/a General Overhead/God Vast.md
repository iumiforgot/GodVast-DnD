A dnd campaign running a very streamlined zine that grants it its world, and some mechanics.
The whole goal of this is to have minimal overhead, tangible progression, and an unlimited ability for roleplay, character development, and eventually, a chance to return back home.
[[Hex Crawl]] , [[Dungeon Crawler]]