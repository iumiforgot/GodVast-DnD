A type of DND playstyle in which players traverse large swaths of land, in search of fabled, or in particularly lucky circumstances, random places to explore, trade, plunder, intrigue, and fight within.
Usually hexagonal grids representing untold miles of land.
In [[God Vast]], it is the main way players will navigate from cities, to dungeons, to pillars, and throughout the wastes.
At this point, it is quite uneventful, proceeding whole days at a time.