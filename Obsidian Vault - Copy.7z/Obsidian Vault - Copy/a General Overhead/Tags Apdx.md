Characters / #players #people 
Handouts / #people #things #places
