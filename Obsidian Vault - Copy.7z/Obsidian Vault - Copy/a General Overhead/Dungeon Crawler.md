The main purpose of a dungeon crawler is to expose players to a myriad of enemies, driving them through repeated combat, and problem solving in order to come out the other side with a boon of loot.
Dungeons usually end in a crescendo, like in [[p1 Starting Spiel]]
In [[God Vast]], the main way players will acquire loot will be through a Dungeon Crawler "vibe"